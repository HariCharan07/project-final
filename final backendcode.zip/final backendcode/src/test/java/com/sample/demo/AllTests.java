package com.sample.demo;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.entity.Admin;

@RunWith(Suite.class)
@SuiteClasses({ AdminTest.class ,BookTest.class, ReviewTest.class, UserTest.class })
public class AllTests {

}
