package com.sample.demo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.entity.Admin;
import com.repo.AdminRepo;
import com.service.AdminService;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(SpringRunner.class)
@SpringBootTest
public class AdminTest {

    @Autowired
    private AdminService adminService;

    @Autowired
    private AdminRepo adminRepo;

    @Before
    public void setUp() {
        adminRepo.deleteAll(); // Clear the repository before each test
    }

    @Test
    public void testAddAdminSuccessfully() {
        Admin admin = new Admin();
        admin.setEmail("admin@gmail.com");
        admin.setAname("Admin");
        admin.setPassword("Admin@123");

        boolean isAdded = adminService.addAdmin(admin);
        assertTrue(isAdded);
    }

    @Test
    public void testAddAdminFailureDueToExistingEmail() {
        Admin admin = new Admin();
        admin.setEmail("admin@gmail.com");
        admin.setAname("Admin");
        admin.setPassword("Admin@123");

        adminService.addAdmin(admin); // First add the admin

        boolean isAdded = adminService.addAdmin(admin); // Try adding the same admin again
        assertFalse(isAdded);
    }

    @Test
    public void testUpdateAdminSuccessfully() {
        Admin admin = new Admin();
        admin.setEmail("admin@gmail.com");
        admin.setAname("Admin");
        admin.setPassword("Admin@123");

        adminService.addAdmin(admin); // Ensure admin exists

        admin.setAname("UpdatedAdmin"); // Update the admin details
        boolean isUpdated = adminService.updateAdmin(admin);
        assertTrue(isUpdated);

        Admin updatedAdmin = adminRepo.findById(admin.getEmail()).orElse(null);
        assertNotNull(updatedAdmin);
        assertEquals("UpdatedAdmin", updatedAdmin.getAname());
    }

    @Test
    public void testValidAdminLoginSuccess() {
        Admin admin = new Admin();
        admin.setEmail("admin@gmail.com");
        admin.setAname("Admin");
        admin.setPassword("Admin@123");

        adminService.addAdmin(admin);

        boolean isAuthenticated = adminService.validateAdmin("admin@gmail.com", "Admin@123");
        assertTrue(isAuthenticated);
    }

    @Test
    public void testValidAdminLoginFailure() {
        Admin admin = new Admin();
        admin.setEmail("admin@gmail.com");
        admin.setAname("Admin");
        admin.setPassword("Admin@123");

        adminService.addAdmin(admin);

        boolean isAuthenticated = adminService.validateAdmin("admin@gmail.com", "WrongPassword");
        assertFalse(isAuthenticated);
    }
}
