package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Admin;
import com.service.AdminService;

@RestController
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired
    AdminService adminService;

    @GetMapping("/getadmin/{email}")
    public ResponseEntity<Boolean> validateUser(@PathVariable("email") String email, @PathVariable("password") String pass) {
        try {
            boolean isValid = adminService.validateAdmin(email, pass);
            return ResponseEntity.ok(isValid);
        } catch (Exception e) {
            // Log the exception (optional)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false);
        }
    }

    @PostMapping("/addAdmin")
    public ResponseEntity<Boolean> addAdmin(@RequestBody Admin admin) {
        try {
            boolean isAdded = adminService.addAdmin(admin);
            return ResponseEntity.ok(isAdded);
        } catch (Exception e) {
            // Log the exception (optional)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false);
        }
    }

    @PutMapping("/updateAdmin")
    public ResponseEntity<Boolean> updateAdmin(@RequestBody Admin admin) {
        try {
            boolean isUpdated = adminService.updateAdmin(admin);
            return ResponseEntity.ok(isUpdated);
        } catch (Exception e) {
            // Log the exception (optional)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false);
        }
    }
}
