package com.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Book;
import com.service.BookService;

//@RestController
@Controller
@CrossOrigin(origins = "*")
public class BookController {

    @Autowired
    BookService bookService;

    @PostMapping("/addBook")
    public ResponseEntity<Boolean> addBook(@RequestBody Book book) {
        try {
            book.setEnable("enable");
            boolean isAdded = bookService.addBook(book);
            return ResponseEntity.ok(isAdded);
        } catch (Exception e) {
            // Log the exception (optional)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false);
        }
    }

    @GetMapping("/getAllBooks")
    public ResponseEntity<List<Book>> getAllBooks() {
        try {
            List<Book> books = bookService.getAllBooks();
            return ResponseEntity.ok(books);
        } catch (Exception e) {
            // Log the exception (optional)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/getEnabledBooks")
    public ResponseEntity<List<Book>> getEnabledBooks() {
        try {
            List<Book> enabledBooks = bookService.getEnabledBooks();
            return ResponseEntity.ok(enabledBooks);
        } catch (Exception e) {
            // Log the exception (optional)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PutMapping("/updateBook")
    public ResponseEntity<Boolean> updateBook(@RequestBody Book book) {
        try {
            boolean isUpdated = bookService.updateBook(book);
            return ResponseEntity.ok(isUpdated);
        } catch (Exception e) {
            // Log the exception (optional)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(false);
        }
    }

    @GetMapping("/getBookByBookName/{bookName}")
    public ResponseEntity<List<Book>> getBookByBookName(@PathVariable("bookName") String book) {
        try {
            List<Book> books = bookService.getBookByName(book);
            return ResponseEntity.ok(books);
        } catch (Exception e) {
            // Log the exception (optional)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DeleteMapping("/deleteBook/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable("id") int id) {
        try {
            if (bookService.deleteBook(id)) {
                return ResponseEntity.ok("Book with id " + id + " is deleted successfully");
            }
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Book not found");
        } catch (Exception e) {
            // Log the exception (optional)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error deleting book");
        }
    }
}
