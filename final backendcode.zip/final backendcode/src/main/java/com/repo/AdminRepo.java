package com.repo; 

 

import org.springframework.data.jpa.repository.JpaRepository; 

import org.springframework.data.jpa.repository.Query; 

 

import com.entity.Admin; 

 

public interface AdminRepo extends JpaRepository<Admin, String> { 

 

@Query("select count(*) from Admin where email=?1") 

public int hasAdmin(String email); 

 

@Query("select aname from Admin where email=?1 and password=?2") 

public String validateLogin(String email, String pass); 

} 